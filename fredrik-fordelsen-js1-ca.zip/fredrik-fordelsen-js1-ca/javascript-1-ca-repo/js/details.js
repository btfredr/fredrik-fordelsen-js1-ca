/*
JavaScript 1 Course Assignment - Fredrik Fordelsen - Level 1
*/

// Declaring parameters and selecting detail container
const params = new URLSearchParams(document.location.search);
const detailContainer = document.querySelector(".detail-container");

// Checking the content's id
let id;

if (params.has("id")) {
    id = params.get("id");
} else {
    // Redirecting to error page if unable to find ID information
    document.location.href = "error.html";
};

// Declaring a const with the given URL, and later specifying it with the id tag
const rMSeriesInfoId = "https://rickandmortyapi.com/api/character/";
const detailInformation = `${rMSeriesInfoId}${id}`;

let html = "";

// Fetching character information
fetch(detailInformation)
    .then(function (response) {
        return response.json();
    })

    .then(function (json) {
        characterInfo(json);
    })

    .catch(function (error) {
        window.location = "error.html";
    });
    
// Using the HTML from the details document and putting it in js to loop through it
function characterInfo(details) {

    html += `<div class="detail-container">
            <img class="details-image" src="${details.image}" alt="${details.name}"/>
            <div class="detail-details">
            <h1>${details.name}</h1>
            <p>Status: <span class="value" id="status">"${details.status}"</span></p>
            <p>Species: <span class="value" id="species">"${details.species}"</span></p>
            <p>Origin: <span class="value" id="origin">"${details.origin.name}"</span></p>
            <p>Location: <span class="value" id="location">"${details.location.name}"</span></p>                   
            </div>
            </div>`;
    detailContainer.innerHTML = html;
};


