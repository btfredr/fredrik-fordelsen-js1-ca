/*
JavaScript 1 Course Assignment - Fredrik Fordelsen - Level 1
*/

// Making a function to change the words in the text
function changeWords() {
  const header = document.querySelector(".container h1");
  const headerText = header.innerText;
  const replaceHeader = headerText.replace("The", "Replaced");
  header.innerText = replaceHeader;

// Selecting the paragraphs and replacing the words
  const paragraphs = document.querySelectorAll("p");
  for (let i = 0; i < paragraphs.length; i++) {

    let originalText = paragraphs[i].innerText;
    originalText = originalText.replace("the", "replaced");
    originalText = originalText.replace("The", "Replaced");
    paragraphs.innerHTML = originalText;
  };
};

// Calling the function with a timeout
setTimeout(changeWords, 4000);